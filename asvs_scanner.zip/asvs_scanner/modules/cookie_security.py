import requests

def check_cookie_security(target_url):
    print(f"\n[*] Checking Cookie Security Controls for: {target_url}")
    
    report_lines = []
    report_lines.append(f"--- Cookie Security Scan Results ---")
    
    try:
        response = requests.get(target_url, timeout=5)
        cookies = response.cookies
        
        if not cookies:
            msg = "  [*] [INFO] No cookies found set by the server on the initial response."
            print(msg)
            report_lines.append(msg)
            return report_lines
            
        for cookie in cookies:
            msg_cookie = f"  [*] Analyzing Cookie: '{cookie.name}'"
            print(msg_cookie)
            report_lines.append(msg_cookie)
            
            # فحص خاصية HttpOnly
            if cookie.has_nonstandard_attr('HttpOnly') or getattr(cookie, 'rest', {}).get('HttpOnly') or 'httponly' in str(cookie._rest).lower():
                msg = f"    [+] [SECURE] HttpOnly is enabled."
                print(msg)
                report_lines.append(msg)
            else:
                msg = f"    [-] [MISSING] HttpOnly attribute is missing!"
                print(msg)
                report_lines.append(msg)
                
            # فحص خاصية Secure
            if cookie.secure:
                msg = f"    [+] [SECURE] Secure flag is enabled."
                print(msg)
                report_lines.append(msg)
            else:
                msg = f"    [-] [MISSING] Secure flag is missing!"
                print(msg)
                report_lines.append(msg)
                
            # فحص خاصية SameSite
            samesite = cookie.get_nonstandard_attr('SameSite') or getattr(cookie, 'rest', {}).get('SameSite')
            if samesite:
                msg = f"    [+] [SECURE] SameSite is set to: {samesite}"
                print(msg)
                report_lines.append(msg)
            else:
                msg = f"    [-] [MISSING] SameSite attribute is missing!"
                print(msg)
                report_lines.append(msg)
                
    except Exception as e:
        err_msg = f"  [-] Error checking cookies: {e}"
        print(err_msg)
        report_lines.append(err_msg)
        
    return report_lines