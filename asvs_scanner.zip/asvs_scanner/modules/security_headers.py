
import requests

def check_security_headers(target_url):
    print(f"\n[*] Checking Security Headers for: {target_url}")
    
    important_headers = [
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Strict-Transport-Security"
    ]
    
    report_lines = []
    report_lines.append(f"--- Security Headers Scan Results ---")
    
    try:
        response = requests.get(target_url, timeout=5)
        headers = response.headers
        
        for header in important_headers:
            if header in headers:
                msg = f"  [+] [FOUND] {header}: {headers.get(header)}"
                print(msg)
                report_lines.append(msg)
            else:
                msg = f"  [-] [MISSING] {header} is missing!"
                print(msg)
                report_lines.append(msg)
                
    except Exception as e:
        err_msg = f"  [-] Error connecting to target: {e}"
        print(err_msg)
        report_lines.append(err_msg)
        
    return report_lines