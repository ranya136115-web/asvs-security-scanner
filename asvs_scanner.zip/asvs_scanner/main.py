import sys
import os
import json
from datetime import datetime
from modules.security_headers import check_security_headers
from modules.cookie_security import check_cookie_security

def generate_json_report(target, timestamp, header_results, cookie_results, json_filename):
    """توليد تقرير احترافي بصيغة JSON مخصص للتكامل مع أنظمة الـ SOC و SIEM"""
    report_data = {
        "scan_metadata": {
            "scanner_name": "OWASP ASVS Security Scanner",
            "target_url": target,
            "scan_timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "version": "2.0.0"
        },
        "modules_results": {
            "security_headers": [line.strip() for line in header_results if "---" not in line and line.strip()],
            "cookie_security": [line.strip() for line in cookie_results if "---" not in line and line.strip()]
        }
    }
    
    with open(json_filename, "w", encoding="utf-8") as f:
        json.dump(report_data, f, indent=4, ensure_ascii=False)

def generate_html_report(target, timestamp, header_results, cookie_results, html_filename):
    """توليد تقرير تفاعلي عالي الجودة بـ HTML"""
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>OWASP ASVS Security Scan Report</title>
    <style>
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f7f6; color: #333; margin: 0; padding: 20px; }}
        .container {{ max-width: 900px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }}
        h1 {{ color: #1a2a3a; border-bottom: 3px solid #007bff; padding-bottom: 10px; text-align: center; }}
        .meta {{ background: #eef2f7; padding: 15px; border-radius: 6px; margin-bottom: 25px; }}
        .meta p {{ margin: 5px 0; font-weight: 500; }}
        .section-title {{ background: #007bff; color: white; padding: 10px 15px; border-radius: 4px; margin-top: 25px; font-size: 1.1em; }}
        ul {{ list-style-type: none; padding-left: 0; }}
        li {{ padding: 10px 14px; margin-bottom: 8px; border-radius: 4px; font-family: 'Courier New', Courier, monospace; font-size: 0.95em; }}
        .secure {{ background-color: #d4edda; color: #155724; border-left: 5px solid #28a745; }}
        .missing {{ background-color: #f8d7da; color: #721c24; border-left: 5px solid #dc3545; }}
        .info {{ background-color: #e2e3e5; color: #383d41; border-left: 5px solid #6c757d; }}
        .cookie-header {{ font-weight: bold; margin-top: 15px; color: #2c3e50; font-family: sans-serif; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🛡️ OWASP ASVS Security Scan Report</h1>
        <div class="meta">
            <p><strong>Target URL:</strong> <a href="{target}" target="_blank">{target}</a></p>
            <p><strong>Scan Timestamp:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        </div>

        <div class="section-title">🔒 Security Headers Scan</div>
        <ul>
"""
    for line in header_results:
        if "---" in line: continue
        clean_line = line.strip()
        if "[FOUND]" in clean_line:
            html_content += f'            <li class="secure">{clean_line}</li>\n'
        elif "[MISSING]" in clean_line:
            html_content += f'            <li class="missing">{clean_line}</li>\n'
        else:
            html_content += f'            <li class="info">{clean_line}</li>\n'

    html_content += """        </ul>

        <div class="section-title">🍪 Cookie Security Scan</div>
        <ul>
"""
    for line in cookie_results:
        if "---" in line: continue
        clean_line = line.strip()
        if "Analyzing Cookie" in clean_line:
            html_content += f'            <p class="cookie-header">📍 {clean_line}</p>\n'
        elif "[SECURE]" in clean_line:
            html_content += f'            <li class="secure">{clean_line}</li>\n'
        elif "[MISSING]" in clean_line:
            html_content += f'            <li class="missing">{clean_line}</li>\n'
        else:
            html_content += f'            <li class="info">{clean_line}</li>\n'

    html_content += """        </ul>
    </div>
</body>
</html>"""

    with open(html_filename, "w", encoding="utf-8") as f:
        f.write(html_content)

def main():
    print("=" * 60)
    print("      🛡️  OWASP ASVS Enterprise Security Scanner v2.0  🛡️   ")
    print("=" * 60)
    
    target = input("\nEnter Target URL (e.g., https://example.com): ").strip()
    
    if not target:
        print("[-] Error: No URL provided!")
        return

    if not target.startswith("http://") and not target.startswith("https://"):
        target = "https://" + target

    print(f"\n[*] Starting Comprehensive Multi-Module Scan for: {target}\n")
    
    # 1. تشغيل الفحوصات المودولية
    header_results = check_security_headers(target)
    cookie_results = check_cookie_security(target)
    
    # 2. إنشاء مجلد التقارير إذا لم يكن موجوداً
    if not os.path.exists("reports"):
        os.makedirs("reports")
        
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # 3. حفظ التقرير النصي (.txt)
    txt_filename = f"reports/comprehensive_report_{timestamp}.txt"
    report_lines = [
        "OWASP ASVS Comprehensive Security Scan Report",
        f"Target URL: {target}",
        f"Scan Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "=" * 60
    ]
    if header_results: report_lines.extend(header_results)
    report_lines.append("-" * 60)
    if cookie_results: report_lines.extend(cookie_results)
    
    with open(txt_filename, "w", encoding="utf-8") as f:
        f.write("\n".join(report_lines))
        
    # 4. حفظ تقرير الـ HTML التفاعلي (.html)
    html_filename = f"reports/comprehensive_report_{timestamp}.html"
    generate_html_report(target, timestamp, header_results, cookie_results, html_filename)
    
    # 5. حفظ تقرير الـ JSON القياسي (.json)
    json_filename = f"reports/comprehensive_report_{timestamp}.json"
    generate_json_report(target, timestamp, header_results, cookie_results, json_filename)
        
    print("\n" + "=" * 60)
    print("  🎉 SCAN COMPLETED SUCCESSFULLY - REPORTS GENERATED:")
    print("=" * 60)
    print(f"  [+] Text Report  : {txt_filename}")
    print(f"  [+] HTML Report  : {html_filename}")
    print(f"  [+] JSON Report  : {json_filename}")
    print("=" * 60)

if __name__ == "__main__":
    main()